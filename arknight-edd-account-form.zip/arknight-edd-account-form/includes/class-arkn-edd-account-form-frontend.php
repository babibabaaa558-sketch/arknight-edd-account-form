<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Arknight_EDD_Account_Form_Frontend {
	const NONCE_ACTION = 'arkn_account_submit';
	const NONCE_UPDATE_ACTION = 'arkn_account_update';
	const EDIT_SHORTCODE = 'arkn_account_edit_form';
	const EDIT_PAGE_OPTION = 'arkn_account_edit_page_id';
	const DOWNLOAD_CATEGORY_TAXONOMY = 'download_category';
	const DOWNLOAD_CATEGORY_SLUG     = 'arknight-endfield-account';
	const DOWNLOAD_CATEGORY_NAME     = 'Arknight Endfield Account';
	const MAX_UPLOAD_IMAGES         = 10;
	const UPLOADED_IMAGE_META_KEY   = 'arkn_uploaded_image_ids';
	/**
	 * @var Arknight_EDD_Account_Form_Admin
	 */
	private $admin;

	/**
	 * @param Arknight_EDD_Account_Form_Admin $admin Admin dependency.
	 */
	public function __construct( Arknight_EDD_Account_Form_Admin $admin ) {
		$this->admin = $admin;
	}

	public function register_shortcode() {
		add_shortcode( 'arknight_account_form', array( $this, 'render_form_shortcode' ) );
		add_shortcode( self::EDIT_SHORTCODE, array( $this, 'render_edit_form_shortcode' ) );
	}

	public function register_assets() {
		wp_register_style( 'arkn-account-form-style', ARKN_EDD_FORM_URL . 'assets/css/style.css', array(), ARKN_EDD_FORM_VERSION );
		wp_register_script( 'arkn-account-form-script', ARKN_EDD_FORM_URL . 'assets/js/form.js', array(), ARKN_EDD_FORM_VERSION, true );
	}

	/**
	 * @return string
	 */
	public function render_form_shortcode() {
		wp_enqueue_style( 'arkn-account-form-style' );
		wp_enqueue_script( 'arkn-account-form-script' );

		if ( ! post_type_exists( 'download' ) ) {
			return '<p class="arkn-message arkn-error">' . esc_html__( 'Easy Digital Downloads فعال نیست. لطفاً EDD را نصب و فعال کنید.', 'arknight-edd-account-form' ) . '</p>';
		}

		$success = isset( $_GET['arkn_submitted'] ) && '1' === sanitize_text_field( wp_unslash( $_GET['arkn_submitted'] ) );
		$server_options = array(
			'asia'            => 'Asia',
			'europe_america'  => 'Europe - America',
		);

		$form_keywords = array(
			'ثبت آگهی آکانت آرکنایت اندفیلد',
			'ثبت آگهی آکانت arknights: endfield',
			'فروش آکانت آرکنایت اندفیلد',
			'فروش آکانت arknights: endfield',
			'ثبت آگهی فوری آکانت آرکنایت اندفیلد',
			'ثبت آگهی فوری آکانت arknights: endfield',
			'فروش سریع آکانت آرکنایت اندفیلد',
			'فروش سریع آکانت arknights: endfield',
			'ثبت آگهی حرفه ای آکانت آرکنایت اندفیلد',
			'ثبت آگهی حرفه ای آکانت arknights: endfield',
			'آگهی فروش آکانت آرکنایت اندفیلد',
			'آگهی فروش آکانت arknights: endfield',
			'فروش امن آکانت آرکنایت اندفیلد',
			'فروش امن آکانت arknights: endfield',
			'ثبت آگهی تضمینی آکانت آرکنایت اندفیلد',
			'ثبت آگهی تضمینی آکانت arknights: endfield',
			'فروش آکانت لول بالا آرکنایت اندفیلد',
			'فروش آکانت لول بالا arknights: endfield',
			'ثبت آگهی آکانت ویژه آرکنایت اندفیلد',
			'ثبت آگهی آکانت ویژه arknights: endfield',
			'فروش آکانت فول اسکین آرکنایت اندفیلد',
			'فروش آکانت فول اسکین arknights: endfield',
			'ثبت آگهی آکانت آماده آرکنایت اندفیلد',
			'ثبت آگهی آکانت آماده arknights: endfield',
			'فروش مستقیم آکانت آرکنایت اندفیلد',
			'فروش مستقیم آکانت arknights: endfield',
			'ثبت فروش آکانت آرکنایت اندفیلد',
			'ثبت فروش آکانت arknights: endfield',
		);

		$form_keyword_url = 'https://gamebani.ir/sell-arknight-endfield-account/';

		ob_start();
		?>
		<div class="arkn-wrap">
			<?php if ( $success ) : ?>
				<div class="arkn-message arkn-success" role="alert">
					<?php esc_html_e( '✅ آگهی با موفقیت ارسال شد و پس از بررسی منتشر می‌شود.', 'arknight-edd-account-form' ); ?>
				</div>
			<?php endif; ?>
			<form class="arkn-account-form" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" enctype="multipart/form-data" novalidate>
				<input type="hidden" name="action" value="arkn_submit_account" />
				<?php wp_nonce_field( self::NONCE_ACTION, 'arkn_nonce' ); ?>

				<div class="arkn-grid">
					<?php $this->render_number_field( 'authority_level', 'آتوریتی لول', 1, 60 ); ?>
					<?php $this->render_custom_select_field( 'server', 'سرور', $server_options ); ?>
					<?php $this->render_number_field( 'character_banner_pity', 'پیتی بنر کاراکتر', 1, 90 ); ?>
					<?php $this->render_number_field( 'weapon_banner_pity', 'پیتی بنر سلاح', 1, 80 ); ?>
					<?php $this->render_number_field( 'standard_banner_pity', 'پیتی بنر استاندارد', 1, 80 ); ?>
					<?php $this->render_number_field( 'remaining_wish', 'مقدار ویش مانده', 1, 300, '/300' ); ?>
					<?php $this->render_number_field( 'orundum', 'تعداد اروبریل', 1, 90 ); ?>
					<?php $this->render_number_field( 'originium', 'تعداد اریجئومتری', 1, 100 ); ?>
					<?php $this->render_number_field( 'arsenal_ticket', 'تعداد ارسنال تیکت', 1, 100 ); ?>

				</div>

				<div class="arkn-selector-group">
					<h3><?php esc_html_e( 'کاراکتر 6 ستاره', 'arknight-edd-account-form' ); ?></h3>
					<?php echo $this->render_image_checkbox_list( 'selected_characters', $this->admin->get_character_images() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>

				<div class="arkn-selector-group">
					<h3><?php esc_html_e( 'سلاح 6 ستاره', 'arknight-edd-account-form' ); ?></h3>
					<?php echo $this->render_image_checkbox_list( 'selected_weapons', $this->admin->get_weapon_images() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>


				<?php $this->render_number_field( 'price', 'قیمت', 1, 99999999 ); ?>

				<div class="arkn-inline-fields">
					<div class="arkn-field arkn-field-half">
						<label for="character_potential"><?php esc_html_e( 'پوتنشال کاراکترها', 'arknight-edd-account-form' ); ?></label>
						<textarea id="character_potential" name="character_potential" rows="5" required data-error="پوتنشال کاراکتر را وارد کنید." placeholder="مثال: P6 Surtr + P5 Exusiai&#10;مثال: P4 Logos, P3 Texas Alter&#10;مثال: P6 Ch'en Alter + P6 Mlynar&#10;مثال: P5 SilverAsh, P4 Eyjafjalla"></textarea>
					</div>

					<div class="arkn-field arkn-field-half">
						<label for="description"><?php esc_html_e( 'توضیحات', 'arknight-edd-account-form' ); ?></label>
						<textarea id="description" name="description" rows="5" required data-error="لطفاً توضیحات را کامل کنید."></textarea>
					</div>
				</div>

								<div class="arkn-field arkn-field-full">
					<input id="arkn_images" class="arkn-image-input" name="arkn_images[]" type="file" accept="image/*" multiple data-max-images="<?php echo esc_attr( self::MAX_UPLOAD_IMAGES ); ?>" />
					<div class="arkn-upload-preview" data-upload-preview></div>
				</div>

				<div class="arkn-form-feedback" role="alert" aria-live="polite"></div>
								<div class="arkn-form-actions">
					<label for="arkn_images" class="arkn-upload-button"><?php esc_html_e( 'آپلود تصاویر (حداکثر 10)', 'arknight-edd-account-form' ); ?></label>
					<button type="submit" class="arkn-submit"><?php esc_html_e( 'ارسال آکانت', 'arknight-edd-account-form' ); ?></button>
				</div>
			</form>
			<div class="arkn-form-keywords" aria-label="کلمات کلیدی فروش">
				<h3><?php esc_html_e( 'کلمات کلیدی فروش', 'arknight-edd-account-form' ); ?></h3>
				<ul>
					<?php foreach ( $form_keywords as $keyword ) : ?>
						<li><a href="<?php echo esc_url( $form_keyword_url ); ?>"><?php echo esc_html( $keyword ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	private function render_custom_select_field( $name, $label, $options, $selected_value = '' ) {
		?>
		<div class="arkn-field">
			<label for="<?php echo esc_attr( $name ); ?>"><?php echo esc_html( $label ); ?></label>
			<div class="arkn-custom-select" data-select-wrap>
				<button type="button" class="arkn-custom-select__trigger" data-select-trigger aria-expanded="false">
					<span data-select-label><?php echo esc_html( isset( $options[ $selected_value ] ) ? $options[ $selected_value ] : __( 'انتخاب کنید', 'arknight-edd-account-form' ) ); ?></span>
				</button>
				<ul class="arkn-custom-select__menu" data-select-menu hidden>
					<?php foreach ( $options as $value => $option_label ) : ?>
						<li>
							<button type="button" data-option="<?php echo esc_attr( $value ); ?>"><?php echo esc_html( $option_label ); ?></button>
						</li>
					<?php endforeach; ?>
				</ul>
				<select id="<?php echo esc_attr( $name ); ?>" name="<?php echo esc_attr( $name ); ?>" required data-error="سرور را انتخاب کنید.">
					<option value=""><?php esc_html_e( 'انتخاب کنید', 'arknight-edd-account-form' ); ?></option>
					<?php foreach ( $options as $value => $option_label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $selected_value, $value ); ?>><?php echo esc_html( $option_label ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
		</div>
		<?php
	}

	private function render_number_field( $name, $label, $min, $max, $suffix = '', $value = '' ) {
		$error = sprintf( 'فیلد %s باید بین %d تا %d باشد.', $label, $min, $max );
		?>
		<div class="arkn-field">
			<label for="<?php echo esc_attr( $name ); ?>"><?php echo esc_html( $label ); ?></label>
			<div class="arkn-number-wrap">
				<input id="<?php echo esc_attr( $name ); ?>" name="<?php echo esc_attr( $name ); ?>" type="number" min="<?php echo esc_attr( $min ); ?>" max="<?php echo esc_attr( $max ); ?>" required value="<?php echo esc_attr( (string) $value ); ?>" data-error="<?php echo esc_attr( $error ); ?>" />
				<?php if ( '' !== $suffix ) : ?>
					<span><?php echo esc_html( $suffix ); ?></span>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	private function render_image_checkbox_list( $name, $items, $selected_values = array() ) {
		if ( empty( $items ) ) {
			return '<p class="arkn-empty">' . esc_html__( 'هنوز تصویری ثبت نشده است. نام فایل‌ها را در تنظیمات وارد کنید.', 'arknight-edd-account-form' ) . '</p>';
		}

		ob_start();
		echo '<div class="arkn-image-grid">';

		foreach ( $items as $index => $item ) {
			if ( empty( $item['name'] ) || empty( $item['file'] ) ) {
				continue;
			}

			$image_url = esc_url( ARKN_EDD_IMG_BASE_URL . ltrim( $item['file'], '/' ) );
			$input_id  = sanitize_html_class( $name . '-' . $index . '-' . $item['name'] );
			?>
			<label class="arkn-card" for="<?php echo esc_attr( $input_id ); ?>">
				<input id="<?php echo esc_attr( $input_id ); ?>" class="arkn-card__input" type="checkbox" name="<?php echo esc_attr( $name ); ?>[]" value="<?php echo esc_attr( $item['name'] ); ?>" <?php checked( in_array( $item['name'], $selected_values, true ) ); ?> />
				<span class="arkn-card__tick" aria-hidden="true">✓</span>
				<img src="<?php echo $image_url; ?>" alt="<?php echo esc_attr( $item['name'] ); ?>" loading="lazy" />
				<span class="arkn-card__name"><?php echo esc_html( $item['name'] ); ?></span>
			</label>
			<?php
		}

		echo '</div>';
		return ob_get_clean();
	}

	public function get_edit_page_url( $post_id ) {
		$post_id = absint( $post_id );
		if ( $post_id <= 0 ) {
			return '';
		}

		$page_id = $this->get_or_create_edit_page_id();
		if ( $page_id <= 0 ) {
			return '';
		}

		return add_query_arg( 'arkn_edit_account_id', $post_id, get_permalink( $page_id ) );
	}

	private function get_or_create_edit_page_id() {
		$page_id = absint( get_option( self::EDIT_PAGE_OPTION, 0 ) );
		if ( $page_id > 0 && 'publish' === get_post_status( $page_id ) ) {
			return $page_id;
		}

		$existing = get_page_by_path( 'arkn-account-edit' );
		if ( $existing instanceof WP_Post ) {
			update_option( self::EDIT_PAGE_OPTION, (int) $existing->ID );
			return (int) $existing->ID;
		}

		$new_page_id = wp_insert_post(
			array(
				'post_title'   => '',
				'post_name'    => 'arkn-account-edit',
				'post_status'  => 'publish',
				'post_type'    => 'page',
				'post_content' => '[' . self::EDIT_SHORTCODE . ']',
			),
			true
		);

		if ( is_wp_error( $new_page_id ) ) {
			return 0;
		}

		update_option( self::EDIT_PAGE_OPTION, (int) $new_page_id );
		return (int) $new_page_id;
	}

	public function render_edit_form_shortcode() {
		if ( ! is_user_logged_in() ) {
			return '<p class="arkn-message arkn-error">' . esc_html__( 'برای ویرایش آکانت ابتدا وارد شوید.', 'arknight-edd-account-form' ) . '</p>';
		}

		$post_id = isset( $_GET['arkn_edit_account_id'] ) ? absint( wp_unslash( $_GET['arkn_edit_account_id'] ) ) : 0;
		$post    = $post_id > 0 ? get_post( $post_id ) : null;
		if ( ! $post || 'download' !== $post->post_type || (int) $post->post_author !== get_current_user_id() ) {
			return '<p class="arkn-message arkn-error">' . esc_html__( 'آکانت معتبری برای ویرایش پیدا نشد.', 'arknight-edd-account-form' ) . '</p>';
		}

		wp_enqueue_style( 'arkn-account-form-style' );
		wp_enqueue_script( 'arkn-account-form-script' );

		$server_options = array(
			'asia'            => 'Asia',
			'europe_america'  => 'Europe - America',
		);

		$values = array(
			'authority_level'       => (string) get_post_meta( $post_id, 'arkn_authority_level', true ),
			'server'                => (string) get_post_meta( $post_id, 'arkn_server', true ),
			'character_banner_pity' => (string) get_post_meta( $post_id, 'arkn_character_banner_pity', true ),
			'weapon_banner_pity'    => (string) get_post_meta( $post_id, 'arkn_weapon_banner_pity', true ),
			'standard_banner_pity'  => (string) get_post_meta( $post_id, 'arkn_standard_banner_pity', true ),
			'remaining_wish'        => (string) get_post_meta( $post_id, 'arkn_remaining_wish', true ),
			'orundum'               => (string) get_post_meta( $post_id, 'arkn_orundum', true ),
			'originium'             => (string) get_post_meta( $post_id, 'arkn_originium', true ),
			'arsenal_ticket'        => (string) get_post_meta( $post_id, 'arkn_arsenal_ticket', true ),
			'character_potential'   => (string) get_post_meta( $post_id, 'arkn_character_potential', true ),
			'price'                 => (string) get_post_meta( $post_id, 'edd_price', true ),
			'description'           => (string) $post->post_content,
			'selected_characters'   => $this->extract_meta_list( (string) get_post_meta( $post_id, 'arkn_selected_characters', true ) ),
			'selected_weapons'      => $this->extract_meta_list( (string) get_post_meta( $post_id, 'arkn_selected_weapons', true ) ),
			'existing_images'       => $this->get_uploaded_images_data( $post_id ),
		);

		$updated = isset( $_GET['arkn_updated'] ) && '1' === sanitize_text_field( wp_unslash( $_GET['arkn_updated'] ) );

		ob_start();
		?>
		<div class="arkn-wrap arkn-wrap--full arkn-edit-page-wrap">
			<?php if ( $updated ) : ?>
				<div class="arkn-message arkn-success" role="alert"><?php esc_html_e( '✅ آکانت با موفقیت بروزرسانی شد و برای بررسی ارسال گردید.', 'arknight-edd-account-form' ); ?></div>
			<?php endif; ?>
			<form class="arkn-account-form" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" enctype="multipart/form-data" novalidate>
				<input type="hidden" name="action" value="arkn_update_account" />
				<input type="hidden" name="account_id" value="<?php echo esc_attr( (string) $post_id ); ?>" />
				<?php wp_nonce_field( self::NONCE_UPDATE_ACTION, 'arkn_nonce' ); ?>
				<div class="arkn-grid">
					<?php $this->render_number_field( 'authority_level', 'آتوریتی لول', 1, 60, '', $values['authority_level'] ); ?>
					<?php $this->render_custom_select_field( 'server', 'سرور', $server_options, $values['server'] ); ?>
					<?php $this->render_number_field( 'character_banner_pity', 'پیتی بنر کاراکتر', 1, 90, '', $values['character_banner_pity'] ); ?>
					<?php $this->render_number_field( 'weapon_banner_pity', 'پیتی بنر سلاح', 1, 80, '', $values['weapon_banner_pity'] ); ?>
					<?php $this->render_number_field( 'standard_banner_pity', 'پیتی بنر استاندارد', 1, 80, '', $values['standard_banner_pity'] ); ?>
					<?php $this->render_number_field( 'remaining_wish', 'مقدار ویش مانده', 1, 300, '/300', (string) absint( str_replace( '/300', '', $values['remaining_wish'] ) ) ); ?>
					<?php $this->render_number_field( 'orundum', 'تعداد اروبریل', 1, 90, '', $values['orundum'] ); ?>
					<?php $this->render_number_field( 'originium', 'تعداد اریجئومتری', 1, 100, '', $values['originium'] ); ?>
					<?php $this->render_number_field( 'arsenal_ticket', 'تعداد ارسنال تیکت', 1, 100, '', $values['arsenal_ticket'] ); ?>
				</div>

				<div class="arkn-selector-group">
					<h3><?php esc_html_e( 'کاراکتر 6 ستاره', 'arknight-edd-account-form' ); ?></h3>
					<?php echo $this->render_image_checkbox_list( 'selected_characters', $this->admin->get_character_images(), $values['selected_characters'] ); ?>
				</div>

				<div class="arkn-selector-group">
					<h3><?php esc_html_e( 'سلاح 6 ستاره', 'arknight-edd-account-form' ); ?></h3>
					<?php echo $this->render_image_checkbox_list( 'selected_weapons', $this->admin->get_weapon_images(), $values['selected_weapons'] ); ?>
				</div>


				<?php $this->render_number_field( 'price', 'قیمت', 1, 99999999, '', $values['price'] ); ?>

				<div class="arkn-inline-fields">
					<div class="arkn-field arkn-field-half">
						<label for="character_potential"><?php esc_html_e( 'پوتنشال کاراکترها', 'arknight-edd-account-form' ); ?></label>
						<textarea id="character_potential" name="character_potential" rows="5" required data-error="پوتنشال کاراکتر را وارد کنید." placeholder="مثال: P6 Surtr + P5 Exusiai&#10;مثال: P4 Logos, P3 Texas Alter&#10;مثال: P6 Ch'en Alter + P6 Mlynar&#10;مثال: P5 SilverAsh, P4 Eyjafjalla"><?php echo esc_textarea( $values['character_potential'] ); ?></textarea>
					</div>

					<div class="arkn-field arkn-field-half">
						<label for="description"><?php esc_html_e( 'توضیحات', 'arknight-edd-account-form' ); ?></label>
						<textarea id="description" name="description" rows="5" required data-error="لطفاً توضیحات را کامل کنید."><?php echo esc_textarea( $values['description'] ); ?></textarea>
					</div>
				</div>


				<div class="arkn-field arkn-field-full">
					<input id="arkn_images" class="arkn-image-input" name="arkn_images[]" type="file" accept="image/*" multiple data-max-images="<?php echo esc_attr( self::MAX_UPLOAD_IMAGES ); ?>" />
					<div class="arkn-upload-preview" data-upload-preview>
						<?php foreach ( $values['existing_images'] as $existing_image ) : ?>
							<div class="arkn-upload-preview__item">
								<img src="<?php echo esc_url( (string) $existing_image['url'] ); ?>" alt="<?php echo esc_attr( (string) $existing_image['alt'] ); ?>" loading="lazy" />
								<span><?php echo esc_html( (string) $existing_image['name'] ); ?></span>
							</div>
						<?php endforeach; ?>
					</div>
				</div>

				<div class="arkn-form-feedback" role="alert" aria-live="polite"></div>
				<div class="arkn-form-actions">
					<label for="arkn_images" class="arkn-upload-button"><?php esc_html_e( 'آپلود تصاویر (حداکثر 10)', 'arknight-edd-account-form' ); ?></label>
					<button type="submit" class="arkn-submit"><?php esc_html_e( 'بروزرسانی', 'arknight-edd-account-form' ); ?></button>
				</div>
			</form>
		</div>
		<?php
		return ob_get_clean();
	}

	public function handle_submission() {
		if ( ! isset( $_POST['arkn_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['arkn_nonce'] ) ), self::NONCE_ACTION ) ) {
			wp_die( esc_html__( 'درخواست نامعتبر است.', 'arknight-edd-account-form' ) );
		}

		if ( ! post_type_exists( 'download' ) ) {
			wp_die( esc_html__( 'Easy Digital Downloads فعال نیست.', 'arknight-edd-account-form' ) );
		}

		$server_whitelist = array( 'asia', 'europe_america' );
		$server           = isset( $_POST['server'] ) ? sanitize_text_field( wp_unslash( $_POST['server'] ) ) : '';
		if ( ! in_array( $server, $server_whitelist, true ) ) {
			wp_die( esc_html__( 'سرور انتخابی معتبر نیست.', 'arknight-edd-account-form' ) );
		}

		$allowed_character_names = $this->extract_allowed_item_names( $this->admin->get_character_images() );
		$allowed_weapon_names    = $this->extract_allowed_item_names( $this->admin->get_weapon_images() );

		$data = array(
			'authority_level'       => $this->sanitize_bounded_number( 'authority_level', 1, 60 ),
			'server'                => $server,
			'character_banner_pity' => $this->sanitize_bounded_number( 'character_banner_pity', 1, 90 ),
			'weapon_banner_pity'    => $this->sanitize_bounded_number( 'weapon_banner_pity', 1, 80 ),
			'standard_banner_pity'  => $this->sanitize_bounded_number( 'standard_banner_pity', 1, 80 ),
			'remaining_wish'        => $this->sanitize_bounded_number( 'remaining_wish', 1, 300 ) . '/300',
			'orundum'               => $this->sanitize_bounded_number( 'orundum', 1, 90 ),
			'originium'             => $this->sanitize_bounded_number( 'originium', 1, 100 ),
			'arsenal_ticket'        => $this->sanitize_bounded_number( 'arsenal_ticket', 1, 100 ),
			'character_potential'   => isset( $_POST['character_potential'] ) ? sanitize_textarea_field( wp_unslash( $_POST['character_potential'] ) ) : '',
			'description'           => isset( $_POST['description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['description'] ) ) : '',
			'price'                 => $this->sanitize_bounded_number( 'price', 1, 99999999 ),
			'selected_characters'   => $this->sanitize_text_list( isset( $_POST['selected_characters'] ) ? wp_unslash( $_POST['selected_characters'] ) : array(), $allowed_character_names ),
			'selected_weapons'      => $this->sanitize_text_list( isset( $_POST['selected_weapons'] ) ? wp_unslash( $_POST['selected_weapons'] ) : array(), $allowed_weapon_names ),
		);

		if ( '' === trim( $data['character_potential'] ) || '' === trim( $data['description'] ) ) {
			wp_die( esc_html__( 'لطفاً تمام فیلدهای الزامی را تکمیل کنید.', 'arknight-edd-account-form' ) );
		}

		$seo_titles = $this->build_seo_titles( $data['server'], (int) $data['authority_level'] );

		$post_id = wp_insert_post(
			array(
				'post_title'   => $seo_titles['primary'],
				'post_type'    => 'download',
				'post_status'  => 'pending',
				'post_content' => $data['description'],
			),
			true
		);

		if ( is_wp_error( $post_id ) ) {
			wp_die( esc_html__( 'خطا در ثبت آگهی. دوباره تلاش کنید.', 'arknight-edd-account-form' ) );
		}

		$this->assign_download_category( $post_id );

		update_post_meta( $post_id, 'edd_price', $data['price'] );
		foreach ( $data as $meta_key => $meta_value ) {
			if ( 'price' === $meta_key ) {
				continue;
			}

			if ( is_array( $meta_value ) && empty( $meta_value ) ) {
				continue;
			}

			update_post_meta( $post_id, 'arkn_' . $meta_key, is_array( $meta_value ) ? implode( ', ', $meta_value ) : $meta_value );
		}

		$this->handle_uploaded_images( $post_id );

		wp_safe_redirect( add_query_arg( 'arkn_submitted', '1', wp_get_referer() ? wp_get_referer() : home_url() ) );
		exit;
	}

	private function get_uploaded_images_data( $post_id ) {
		$image_ids = $this->extract_meta_list( (string) get_post_meta( $post_id, self::UPLOADED_IMAGE_META_KEY, true ) );
		$images    = array();

		foreach ( $image_ids as $id_raw ) {
			$attachment_id = absint( $id_raw );
			if ( $attachment_id <= 0 ) {
				continue;
			}

			$image_url = wp_get_attachment_image_url( $attachment_id, 'medium' );
			if ( ! $image_url ) {
				continue;
			}

			$alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
			if ( '' === $alt ) {
				$alt = get_the_title( $attachment_id );
			}

			$images[] = array(
				'url'  => esc_url( $image_url ),
				'alt'  => sanitize_text_field( (string) $alt ),
				'name' => sanitize_text_field( (string) wp_basename( (string) wp_get_attachment_url( $attachment_id ) ) ),
			);
		}

		return $images;
	}

	public function handle_update_submission() {
		if ( ! is_user_logged_in() ) {
			wp_die( esc_html__( 'برای ویرایش آکانت ابتدا وارد شوید.', 'arknight-edd-account-form' ) );
		}

		if ( ! isset( $_POST['arkn_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['arkn_nonce'] ) ), self::NONCE_UPDATE_ACTION ) ) {
			wp_die( esc_html__( 'درخواست نامعتبر است.', 'arknight-edd-account-form' ) );
		}

		$post_id = isset( $_POST['account_id'] ) ? absint( wp_unslash( $_POST['account_id'] ) ) : 0;
		$post    = $post_id > 0 ? get_post( $post_id ) : null;
		if ( ! $post || 'download' !== $post->post_type || (int) $post->post_author !== get_current_user_id() ) {
			wp_die( esc_html__( 'شما اجازه ویرایش این آکانت را ندارید.', 'arknight-edd-account-form' ) );
		}

		$server_whitelist = array( 'asia', 'europe_america' );
		$server           = isset( $_POST['server'] ) ? sanitize_text_field( wp_unslash( $_POST['server'] ) ) : '';
		if ( ! in_array( $server, $server_whitelist, true ) ) {
			wp_die( esc_html__( 'سرور انتخابی معتبر نیست.', 'arknight-edd-account-form' ) );
		}

		$allowed_character_names = $this->extract_allowed_item_names( $this->admin->get_character_images() );
		$allowed_weapon_names    = $this->extract_allowed_item_names( $this->admin->get_weapon_images() );

		$data = array(
			'authority_level'       => $this->sanitize_bounded_number( 'authority_level', 1, 60 ),
			'server'                => $server,
			'character_banner_pity' => $this->sanitize_bounded_number( 'character_banner_pity', 1, 90 ),
			'weapon_banner_pity'    => $this->sanitize_bounded_number( 'weapon_banner_pity', 1, 80 ),
			'standard_banner_pity'  => $this->sanitize_bounded_number( 'standard_banner_pity', 1, 80 ),
			'remaining_wish'        => $this->sanitize_bounded_number( 'remaining_wish', 1, 300 ) . '/300',
			'orundum'               => $this->sanitize_bounded_number( 'orundum', 1, 90 ),
			'originium'             => $this->sanitize_bounded_number( 'originium', 1, 100 ),
			'arsenal_ticket'        => $this->sanitize_bounded_number( 'arsenal_ticket', 1, 100 ),
			'character_potential'   => isset( $_POST['character_potential'] ) ? sanitize_textarea_field( wp_unslash( $_POST['character_potential'] ) ) : '',
			'description'           => isset( $_POST['description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['description'] ) ) : '',
			'price'                 => $this->sanitize_bounded_number( 'price', 1, 99999999 ),
			'selected_characters'   => $this->sanitize_text_list( isset( $_POST['selected_characters'] ) ? wp_unslash( $_POST['selected_characters'] ) : array(), $allowed_character_names ),
			'selected_weapons'      => $this->sanitize_text_list( isset( $_POST['selected_weapons'] ) ? wp_unslash( $_POST['selected_weapons'] ) : array(), $allowed_weapon_names ),
		);

		if ( '' === trim( $data['character_potential'] ) || '' === trim( $data['description'] ) ) {
			wp_die( esc_html__( 'لطفاً تمام فیلدهای الزامی را تکمیل کنید.', 'arknight-edd-account-form' ) );
		}

		$seo_titles = $this->build_seo_titles( $data['server'], (int) $data['authority_level'] );

		wp_update_post(
			array(
				'ID'           => $post_id,
				'post_title'   => $seo_titles['primary'],
				'post_content' => $data['description'],
				'post_status'  => 'pending',
			)
		);

		update_post_meta( $post_id, 'edd_price', $data['price'] );
		foreach ( $data as $meta_key => $meta_value ) {
			if ( 'price' === $meta_key ) {
				continue;
			}
			update_post_meta( $post_id, 'arkn_' . $meta_key, is_array( $meta_value ) ? implode( ', ', $meta_value ) : $meta_value );
		}

		$this->handle_uploaded_images( $post_id );
		$redirect = $this->get_edit_page_url( $post_id );
		if ( '' === $redirect ) {
			$redirect = home_url();
		}

		wp_safe_redirect( add_query_arg( array( 'arkn_updated' => '1', 'arkn_edit_account_id' => $post_id ), $redirect ) );
		exit;
	}

	private function extract_meta_list( $meta ) {
		if ( '' === $meta ) {
			return array();
		}

		$items = array_map( 'trim', explode( ',', $meta ) );
		$items = array_filter(
			$items,
			static function ( $item ) {
				return '' !== $item;
			}
		);

		return array_values( array_unique( $items ) );
	}

			private function assign_download_category( $post_id ) {
		if ( ! taxonomy_exists( self::DOWNLOAD_CATEGORY_TAXONOMY ) ) {
			return;
		}

		$term = get_term_by( 'slug', self::DOWNLOAD_CATEGORY_SLUG, self::DOWNLOAD_CATEGORY_TAXONOMY );

		if ( ! $term || is_wp_error( $term ) ) {
			$term_result = wp_insert_term(
				self::DOWNLOAD_CATEGORY_NAME,
				self::DOWNLOAD_CATEGORY_TAXONOMY,
				array(
					'slug' => self::DOWNLOAD_CATEGORY_SLUG,
				)
			);

			if ( is_wp_error( $term_result ) || empty( $term_result['term_id'] ) ) {
				return;
			}

			$term_id = (int) $term_result['term_id'];
		} else {
			$term_id = (int) $term->term_id;
		}

		if ( $term_id > 0 ) {
			wp_set_object_terms( $post_id, array( $term_id ), self::DOWNLOAD_CATEGORY_TAXONOMY, false );
		}
	}


	private function handle_uploaded_images( $post_id ) {
		if ( empty( $_FILES['arkn_images'] ) || empty( $_FILES['arkn_images']['name'] ) ) {
			return;
		}

		$names = isset( $_FILES['arkn_images']['name'] ) && is_array( $_FILES['arkn_images']['name'] ) ? $_FILES['arkn_images']['name'] : array();
		if ( count( $names ) > self::MAX_UPLOAD_IMAGES ) {
			wp_die( esc_html__( 'حداکثر 10 تصویر قابل آپلود است.', 'arknight-edd-account-form' ) );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$uploaded_image_ids = array();
		$files              = $_FILES['arkn_images'];

		foreach ( $names as $index => $name ) {
			if ( empty( $name ) ) {
				continue;
			}

			if ( empty( $files['type'][ $index ] ) || 0 !== strpos( (string) $files['type'][ $index ], 'image/' ) ) {
				continue;
			}

			$_FILES['arkn_single_upload'] = array(
				'name'     => $files['name'][ $index ],
				'type'     => $files['type'][ $index ],
				'tmp_name' => $files['tmp_name'][ $index ],
				'error'    => $files['error'][ $index ],
				'size'     => $files['size'][ $index ],
			);

			$attachment_id = media_handle_upload( 'arkn_single_upload', $post_id );
			if ( ! is_wp_error( $attachment_id ) ) {
				$uploaded_image_ids[] = (int) $attachment_id;
			}
		}

		unset( $_FILES['arkn_single_upload'] );

		if ( ! empty( $uploaded_image_ids ) ) {
			update_post_meta( $post_id, self::UPLOADED_IMAGE_META_KEY, implode( ',', $uploaded_image_ids ) );
		}
	}


	/**
	 * @param string $server Server value.
	 * @param int    $authority_level Authority level.
	 * @return array<string,string>
	 */
	public function build_seo_titles( $server, $authority_level ) {
		$server_label = strtoupper( sanitize_text_field( (string) $server ) );
		$level        = max( 1, absint( $authority_level ) );

		return array(
			'primary' => sprintf( 'arknights: endfield account - %1$s - Lv %2$d', $server_label, $level ),
			'legacy'  => sprintf( 'Arknight Account - %1$s - Lv %2$d', $server_label, $level ),
			'fa'      => sprintf( 'آکانت آرکنایت اندفیلد - %1$s - Lv %2$d', $server_label, $level ),
		);
	}

	private function sanitize_bounded_number( $field_name, $min, $max ) {
		$value = isset( $_POST[ $field_name ] ) ? absint( wp_unslash( $_POST[ $field_name ] ) ) : 0;
		if ( $value < $min || $value > $max ) {
			wp_die( esc_html__( 'مقدار عددی خارج از بازه مجاز است.', 'arknight-edd-account-form' ) );
		}
		return $value;
	}

	private function sanitize_text_list( $values, $allowed = array() ) {
		if ( ! is_array( $values ) ) {
			return array();
		}

		$clean = array();
		foreach ( $values as $value ) {
			$text = sanitize_text_field( $value );
			if ( '' === $text ) {
				continue;
			}

			if ( ! empty( $allowed ) && ! in_array( $text, $allowed, true ) ) {
				continue;
			}

			$clean[] = $text;
		}

		return array_values( array_unique( $clean ) );
	}

	private function extract_allowed_item_names( $items ) {
		if ( ! is_array( $items ) ) {
			return array();
		}

		$names = array();
		foreach ( $items as $item ) {
			if ( ! is_array( $item ) || empty( $item['name'] ) ) {
				continue;
			}
			$name = sanitize_text_field( $item['name'] );
			if ( '' !== $name ) {
				$names[] = $name;
			}
		}

		return array_values( array_unique( $names ) );
	}

}
