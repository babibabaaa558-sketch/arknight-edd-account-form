<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Arknight_EDD_Account_Form_Home_Slider {
	const SHORTCODE = 'arknight_endfield_accounts_slider';

	/**
	 * @var Arknight_EDD_Account_Form_Product_Cards
	 */
	private $product_cards;

	/**
	 * @param Arknight_EDD_Account_Form_Product_Cards $product_cards Product cards service.
	 */
	public function __construct( Arknight_EDD_Account_Form_Product_Cards $product_cards ) {
		$this->product_cards = $product_cards;
	}

	public function register_shortcode() {
		add_shortcode( self::SHORTCODE, array( $this, 'render_shortcode' ) );
	}

	public function register_assets() {
		wp_register_style( 'arkn-home-slider-style', ARKN_EDD_FORM_URL . 'assets/css/home-slider.css', array( 'arkn-account-cards-style' ), ARKN_EDD_FORM_VERSION );
		wp_register_script( 'arkn-home-slider-script', ARKN_EDD_FORM_URL . 'assets/js/home-slider.js', array(), ARKN_EDD_FORM_VERSION, true );
	}

	/**
	 * @param array<string,mixed> $atts Shortcode attributes.
	 * @return string
	 */
	public function render_shortcode( $atts ) {
		wp_enqueue_style( 'arkn-account-cards-style' );
		wp_enqueue_style( 'arkn-home-slider-style' );
		wp_enqueue_script( 'arkn-account-cards-script' );
		wp_enqueue_script( 'arkn-home-slider-script' );

		if ( ! post_type_exists( 'download' ) ) {
			return '<p class="arkn-product-cards__message">' . esc_html__( 'Easy Digital Downloads فعال نیست.', 'arknight-edd-account-form' ) . '</p>';
		}

		$atts = shortcode_atts(
			array(
				'title'          => 'آکانت های Arknight Endfield',
				'button_text'    => 'مشاهده همه',
				'button_url'     => home_url( '/buy-arknight-endfield-account/' ),
				'posts_per_page' => 12,
				'orderby'        => 'date',
				'order'          => 'DESC',
			),
			$atts,
			self::SHORTCODE
		);

		$query_args = array(
			'post_type'      => 'download',
			'post_status'    => 'publish',
			'posts_per_page' => max( 1, absint( $atts['posts_per_page'] ) ),
			'orderby'        => sanitize_key( $atts['orderby'] ),
			'order'          => 'ASC' === strtoupper( (string) $atts['order'] ) ? 'ASC' : 'DESC',
			'no_found_rows'  => true,
		);

		if ( taxonomy_exists( Arknight_EDD_Account_Form_Frontend::DOWNLOAD_CATEGORY_TAXONOMY ) ) {
			$query_args['tax_query'] = array(
				array(
					'taxonomy' => Arknight_EDD_Account_Form_Frontend::DOWNLOAD_CATEGORY_TAXONOMY,
					'field'    => 'slug',
					'terms'    => Arknight_EDD_Account_Form_Frontend::DOWNLOAD_CATEGORY_SLUG,
				),
			);
		}

		$query = new WP_Query( $query_args );
		if ( ! $query->have_posts() ) {
			return '<p class="arkn-product-cards__message">' . esc_html__( 'فعلاً محصولی برای نمایش وجود ندارد.', 'arknight-edd-account-form' ) . '</p>';
		}

		$cards = $this->product_cards->prepare_cards_data( $query, false );
		wp_reset_postdata();

		$template_file = ARKN_EDD_FORM_DIR . 'templates/shortcode-arkn-home-slider.php';
		if ( ! file_exists( $template_file ) ) {
			return '';
		}

		$slider_id = uniqid( 'arkn-home-slider-', false );

		ob_start();
		require $template_file;
		return ob_get_clean();
	}
}
