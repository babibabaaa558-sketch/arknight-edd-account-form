<?php
/**
 * Home slider shortcode template.
 *
 * @var array<int,array<string,mixed>> $cards
 * @var array<string,mixed>            $atts
 * @var string                         $slider_id
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section id="<?php echo esc_attr( $slider_id ); ?>" class="arkn-home-slider" dir="rtl" data-arkn-home-slider data-arkn-cards>
	<div class="arkn-home-slider__head">
		<div class="arkn-home-slider__head-text">
			<h3 class="arkn-home-slider__title"><?php echo esc_html( (string) $atts['title'] ); ?></h3>
			<?php if ( ! empty( $atts['description'] ) ) : ?>
				<p class="arkn-home-slider__description"><?php echo esc_html( (string) $atts['description'] ); ?></p>
			<?php endif; ?>
		</div>
		<a class="arkn-home-slider__button" href="<?php echo esc_url( (string) $atts['button_url'] ); ?>"><?php echo esc_html( (string) $atts['button_text'] ); ?></a>
	</div>

	<div class="arkn-home-slider__wrap">
		<button type="button" class="arkn-home-slider__nav is-prev" data-arkn-slider-prev aria-label="قبلی">‹</button>
		<div class="arkn-home-slider__viewport" data-arkn-slider-viewport>
			<div class="arkn-home-slider__track">
				<?php foreach ( $cards as $card_data ) : ?>
					<div class="arkn-home-slider__slide">
						<?php require ARKN_EDD_FORM_DIR . 'templates/partials/product-card.php'; ?>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<button type="button" class="arkn-home-slider__nav is-next" data-arkn-slider-next aria-label="بعدی">›</button>
	</div>
</section>
